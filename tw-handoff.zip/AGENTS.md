# TW — компилятор виджетов Telegram «JSON → HTML» (пакет для SAYF)

Технология вышла 9 ноября 2026 (Bot API 10.4) — **по памяти её не знаешь**. Каждый факт о виджетах бери из файлов ниже,
не из обучения и не из опыта с Mini Apps (это другое: там WebView и сеть, здесь QuickJS без сети).

## Что читать и в каком порядке

0. `docs/PLAN.md` — план работ по фазам (структура, API, формат, тесты, критерии готовности). Идёшь по нему.
1. `docs/input/spec-TW.md` — **контракт**. Главнее всего остального. Что строим, требования §4, каталог §5, сценарии §6, «готово, когда» §9.
2. `docs/telegram/widget-author-guide.md` — официальный гайд автора виджета (вывод `sandbox-node.ts --guide`): что разрешено в HTML/CSS/JS.
3. `docs/telegram/bot-api-10.4-widgets.md` — методы и типы Bot API 10.4 дословно (sendWidget, answerWidgetQuery, editMessageWidgetData,
   WidgetQuery, Update.widget_query …). Типы в `src/` пишутся **по этому файлу**, поле в поле.
4. `vendor/widget-sandbox/docs/` — первоисточники Telegram: `widget-runtime-profile.md` (лимиты рантайма), `profile-v1.md` (полный список
   тегов/CSS/событий Profile 1), `sdk-v1.md` (TelegramWidget API), `tgw-format.md`, `integration.md`. `vendor/widget-sandbox/CLAUDE.md` — устройство песочницы.
5. `docs/input/research-gemini.md` — справочник с расчётами. **Есть неточности**; при расхождении верь пунктам 1–4.
6. `docs/reference/json-render/` — идеи формата каталога (`core.md`, `codegen.md`) и Jev (`jev.md`). **Только идеи**: Zod, React,
   npm-пакеты json-render в `src/` запрещены (spec §4.2).

## Жёсткие правила пакета (из spec §4 — не ослаблять)

- TypeScript strict, ESM, относительные импорты **с `.ts`**, вход `src/index.ts`. Работает и в Deno 2 (`deno check/lint/test`), и в vitest.
- `src/` без зависимостей: ни Zod, ни grammY, ни node-telegram-bot-api, ни json-render. Без `Deno.*`, `process`, `fs`, `fetch`, `Date`, `Math.random`.
  zlib — только через порт `Deflate9`; реализация на `node:zlib` — отдельный `src/measure-node.ts`, ядро его не импортирует.
- Детерминизм: одинаковый вход → байт в байт одинаковый HTML, `chat_data`, caption.
- Бюджеты: HTML ≤ 32 768 байт UTF-8; **zlib-9 ≤ 3 800** (не 4 096 — Node и сервер Telegram расходятся: на `corpus/bot-demos/01-order.html`
  Node даёт 3 772, Python 3 738); `chat_data` ≤ 1 024 байт UTF-8; caption ≤ 1 024 знаков; **высота ≤ 560 px на ширине 320 px** (не 360).
- Не влезло → свёртка по шагам spec §4.7 с записью в `degraded`, затем типизированная ошибка `too_large`. Молча не обрезать. Кнопки действий не выпадают.
- В HTML: только `--tg-theme-*` цвета, без `vh`, без внешних шрифтов/картинок, без «тяжёлых» эффектов (blur-тень, `filter`, `opacity < 1`).
  Нет `<input>/<select>/<textarea>`, нет сети, нет прокрутки. Связыватель `chat_data` — только `textContent` и атрибуты из белого списка.
- Модель в пакете не зовётся никогда. Пакет отдаёт JSON Schema (`schema/widget-spec.v1.json`) и `promptGuide()`; генерирует ядро SAYF на Python.
- Не строить бота, базу, права, очереди (spec §10). Живой бот — только `examples/`, ключ из окружения.

## Проверенные факты (ноябрь 2026, сверено с первоисточниками)

- `answerWidgetQuery.data` — 0–1 024 байта; `widget_query` от виджета — до 64 байт; лимит **5 запросов за 5 с на пользователя** (официально, тип WidgetQuery).
- В продакшене виджеты только в личном чате с ботом; сообщения защищены от пересылки.
- Старый клиент видит «неподдерживаемое медиа» + caption → caption обязателен и должен быть читаемым сам по себе.
- Нулевой байт U+0000 в HTML → сервер отвергает (`INPUT_MEDIA_WIDGET_HTML_INVALID`).

## Обязательная проверка каждого HTML, который выдаёт компилятор

```bash
scripts/check-widget.sh fixtures/*.expected.html
```

Скрипт: точный zlib-9 через Python (как сервер Telegram), U+0000, официальный валидатор Profile 1 в QuickJS, высота в Chromium на 320 px,
«тяжёлые» элементы. **Песочница сама возвращает 0 даже при нарушениях** — скрипт падает на любой строке `diag`. Задача не готова, пока он не зелёный.

Отладка одного виджета с нажатиями/состоянием: `cd vendor/widget-sandbox && corepack pnpm tsx packages/core/scripts/sandbox-node.ts <abs.html> --verbose --width 320 --message private --chat-data '{"r":1}'`
(все флаги печатает запуск без аргументов). Визуально: `cd vendor/widget-sandbox && corepack pnpm dev` → http://127.0.0.1:5173.
Образцы хороших виджетов: `vendor/widget-sandbox/corpus/bot-demos/`, `packages/conformance/visual/`.

## Окружение

- `scripts/setup-vendor.sh` — клонирует `vendor/` на закреплённых коммитах (widget-sandbox, json-render, telegym), ставит песочницу и Deno.
  `vendor/` не коммитится.
- `scripts/gen-botapi-docs.py` — пересобирает `docs/telegram/bot-api-10.4-widgets.md` из `vendor/telegym/pkg/mock/spec/api.json`.
- `vendor/telegym` — мок Bot API 10.4 на Go (принимает `sendWidget`, инжектит `widget_query`); нужен только для `examples/`.
- Context7 MCP (`.mcp.json`) — свежие доки библиотек dev-зависимостей (vitest, fast-check, Playwright). Не для Telegram-виджетов: там первоисточник — файлы выше.
