# План реализации TW — компилятор виджетов Telegram «JSON → HTML»

**Дата:** 2026-11-19 · **Статус:** план, кода ещё нет · **Исполнитель:** любая coding-LLM или человек

Этот документ — пошаговый план для исполнителя, который получает репозиторий с нуля. Он не заменяет контракт: **`docs/input/spec-TW.md`
главнее** этого плана. Если план и контракт расходятся — прав контракт, а расхождение надо записать в `docs/DECISIONS.md` (§12).

---

## 0. Как читать этот план (для исполнителя)

1. Прочитай `CLAUDE.md` (правила и порядок чтения), затем `docs/input/spec-TW.md` целиком, затем `docs/telegram/widget-author-guide.md`.
2. Остальное — по ссылкам из нужной фазы. Не пиши ничего о виджетах по памяти: технология вышла 9.11.2026, обучающих данных о ней нет.
3. Работай фазами §9 по порядку. Фаза закрыта, когда выполнены все пункты её «Готово, когда».
4. После каждой фазы: `deno task check` и `npm test` зелёные, `scripts/check-widget.sh fixtures/*.expected.html` зелёный, коммит.
5. Любое своё решение, которого нет в контракте и в §4–§8 этого плана, — строкой в `docs/DECISIONS.md` (что решил, почему, что отверг).

**Карта источников:**

| Вопрос | Где ответ |
| :--- | :--- |
| Что строим, требования, каталог, сценарии, критерии | `docs/input/spec-TW.md` |
| Что разрешено в HTML/CSS/JS виджета, лимиты, SDK кратко | `docs/telegram/widget-author-guide.md` |
| Полный список тегов/атрибутов/CSS/селекторов Profile 1 | `vendor/widget-sandbox/docs/profile-v1.md` |
| `TelegramWidget` подробно (request, chatData, события, ошибки) | `vendor/widget-sandbox/docs/sdk-v1.md` |
| Лимиты рантайма (CPU, узлы, память) | `vendor/widget-sandbox/docs/widget-runtime-profile.md` |
| Методы и типы Bot API 10.4 поле в поле | `docs/telegram/bot-api-10.4-widgets.md` |
| Расчёты сжатия, обзор экосистемы (есть неточности) | `docs/input/research-gemini.md` |
| Идеи формата каталога (не код!) | `docs/reference/json-render/*.md` |
| Хорошие образцы виджетов | `vendor/widget-sandbox/corpus/bot-demos/*.html` |

---

## 1. Цель одним абзацем

Пакет TypeScript без зависимостей `telegram-widgets`: на вход — описание виджета (JSON по каталогу из 14 компонентов), на выход —
детерминированный HTML виджета Telegram (≤ 32 768 байт, ≤ 3 800 байт zlib-9, ≤ 560 px высоты на 320 px), начальная строка `chat_data`,
caption для старых клиентов и отчёт о размерах и свёртках. Либо типизированная ошибка. Плюс: JSON Schema и текст подсказки модели для
ядра SAYF на Python, минимальные типы Bot API 10.4 и чистые помощники для шлюза, золотой набор образцов. Бота, базы, прав — нет.

---

## 2. Итоговая структура репозитория

```
CLAUDE.md, AGENTS.md            правила для агентов (есть)
docs/                           контракт, исследование, справочники (есть) + DECISIONS.md, API.md (создать)
scripts/                        check-widget.sh, setup-vendor.sh, gen-botapi-docs.py (есть) + новые ниже
vendor/                         не коммитится; widget-sandbox, json-render, telegym

deno.json                       задачи deno, import map для тестов
package.json                    только devDependencies: vitest, fast-check, ajv, typescript, @types/node
tsconfig.json                   strict, allowImportingTsExtensions, noEmit, moduleResolution bundler
vitest.config.ts

src/
  index.ts                      единственный публичный вход (реэкспорт)
  types.ts                      WidgetSpec v1 и все узлы каталога (§4)
  limits.ts                     ЕДИНЫЙ источник пределов: из него валидатор, схема, promptGuide
  errors.ts                     WidgetError (дискриминированное объединение), Result<T>
  validate.ts                   рукописная проверка unknown → WidgetSpec | ошибки с путями
  sanitize.ts                   U+0000, управляющие, нормализация строк
  escape.ts                     экранирование текста, атрибутов, JSON внутри <script>
  compile.ts                    compileWidget(): оркестратор (§6)
  render/
    context.ts                  RenderCtx: счётчик id, набор CSS-ключей, флаги рантайма
    css.ts                      фрагменты CSS по ключам в фиксированном порядке
    components/*.ts             по файлу на компонент: render(node, ctx) → string
    runtime.ts                  JS виджета: связыватель, запросы, страницы, вкладки, «Ещё» — собирается из кусочков
  layout/height.ts              прогноз высоты на 320 px (§7)
  degrade.ts                    шаги свёртки (§6.3)
  budget.ts                     измерения: utf8Bytes, deflated через порт, chatData, caption
  state.ts                      chatDataOf(spec, state)
  caption.ts                    сборка caption, обрезка по знакам
  links.ts                      проверка ссылок по allowedOrigins
  botapi/types.ts               минимальные типы Bot API 10.4 (по docs/telegram/bot-api-10.4-widgets.md)
  botapi/helpers.ts             toSendWidgetParams, toEditWidgetDataParams, answerPayload
  schema.ts                     JSON Schema как объект TS, строится из limits.ts
  prompt.ts                     promptGuide(catalog)
  measure-node.ts               Deflate9 на node:zlib — ядро НЕ импортирует

schema/widget-spec.v1.json      генерируется scripts/build-schema.ts, коммитится
fixtures/<имя>.spec.json        вход
fixtures/<имя>.expected.html    ожидаемый HTML
fixtures/<имя>.expected.json    размеры, chat_data, caption, degraded — или ожидаемая ошибка
tests/                          *.test.ts — одни и те же файлы для vitest и deno (§8.1)
scripts/build-schema.ts         пишет schema/widget-spec.v1.json
scripts/build-fixtures.ts       перегенерирует expected-файлы (только по явной команде --update)
scripts/calibrate-height.ts     прогноз высоты против реального замера песочницы (§7.3)
scripts/check-schema.py         проверка схемы и образцов Python-библиотекой jsonschema (как увидит ядро SAYF)
examples/telegym-bot/           по желанию, фаза 7
```

---

## 3. Публичный API пакета (`src/index.ts`)

```ts
export type Deflate9 = (bytes: Uint8Array) => number;   // длина после zlib уровня 9

export interface CompileOptions {
  deflate9: Deflate9;                 // обязателен: ядро не знает zlib
  allowedOrigins: readonly string[];  // "https://acme.sayf.example" — ссылки только отсюда
  botUsername?: string;               // для openTelegramLink: только https://t.me/<botUsername>
  limits?: Partial<Budgets>;          // только УЖЕСТОЧАТЬ; ослабить нельзя (валидатор отвергнет)
  words?: ServiceWords;               // служебные слова; по умолчанию знаки, не слова (§4.6)
}

export interface Budgets { htmlBytes: 32768; deflated: 3800; chatDataBytes: 1024; captionChars: 1024; height320: 560 }

export interface CompileResult {
  html: string;
  chatData: string;          // начальная строка для sendWidget.chat_data
  caption: string;           // ≤ 1024 знаков, всегда непустой
  sizes: { utf8Bytes: number; deflatedBytes: number; chatDataBytes: number; predictedHeight320: number };
  degraded: string[];        // шаги свёртки по порядку, напр. "collapse:text#3", "paginate:list#1", "truncate:text#5"
}

export function compileWidget(spec: unknown, opts: CompileOptions): Result<CompileResult, WidgetError>;
export function validateSpec(spec: unknown, opts?: { allowedOrigins?: readonly string[] }): Result<WidgetSpec, WidgetError>;
export function chatDataOf(spec: WidgetSpec, state: WidgetState): Result<string, WidgetError>;
export function promptGuide(catalog?: Catalog): string;
export const widgetSpecSchema: JsonSchema;       // то же, что schema/widget-spec.v1.json
export const catalog: Catalog;                   // компоненты + пределы из limits.ts
export * from "./botapi/types.ts";
export { toSendWidgetParams, toEditWidgetDataParams, answerPayload } from "./botapi/helpers.ts";
export type { WidgetSpec, WidgetState, WidgetError, Result } from "...";
```

```ts
// src/measure-node.ts — подключает хост: Deno (node:zlib есть), Node, Vite-SSR
import { deflateSync } from "node:zlib";
export const deflate9Node: Deflate9 = (b) => deflateSync(b, { level: 9 }).length;
```

**Ошибки** (`src/errors.ts`) — объединение по полю `code`, без исключений наружу:

| code | Когда | Поля |
| :--- | :--- | :--- |
| `invalid_spec` | не прошло проверку | `issues: { path: string; message: string }[]` (все, не первая) |
| `link_not_allowed` | адрес не https или не из allowedOrigins | `path`, `url` |
| `action_too_long` | строка действия > 64 байт UTF-8 | `path`, `bytes` |
| `chat_data_too_large` | chatData > 1024 байт | `bytes` |
| `too_large` | после всех свёрток не влезло | `sizes`, `degraded`, `reason: "deflated" \| "html" \| "height"` |

`compileWidget` не бросает исключений ни на каком входе (это проверяет fast-check, §8.4).

---

## 4. Формат описания v1 (уточнение §5 контракта)

### 4.1. Корень

```jsonc
{
  "v": 1,
  "root": { "type": "Card", "children": [ /* узлы */ ] },
  "state":   { "r": 1, "status": "in_progress", "progress": 40, "act": ["submit", "more"] },
  "actions": { "claim": "t:Ab3kQ9…:claim", "submit": "t:Ab3kQ9…:submit", "extend": null },
  "links":   { "open": "https://acme.sayf.example/w/tasks?open=…" },
  "caption": "Задача «Сверить счёт» · в работе · срок 21.11",
  "dir": "ltr",                 // необязательно; "rtl" ставит dir на корень
  "lang": "ru"                  // необязательно; атрибут lang (переносы, шрифты клиента)
}
```

* `state` — плоский объект: ключи `[a-z][a-z0-9_]{0,15}`, значения — строка ≤ 64 знаков, целое число, boolean или массив имён действий.
  Ключ `r` (ревизия, целое ≥ 0) обязателен. Ключ `act` зарезервирован (§4.4).
* `actions` — имя → непрозрачная строка хоста ≤ 64 байт UTF-8, или `null` (действие сейчас недоступно и **не попадает в HTML**).
* `links` — имя → https-адрес; проверяется по `allowedOrigins` при компиляции.
* `caption` — необязательно; если нет, собирается из текстов `Header`/`Text`/`KeyValue` (§6.4).

### 4.2. Узлы каталога (14 типов)

Общие необязательные поля любого узла: `id` (строка `[a-z0-9_-]{1,24}`, нужна для `degraded` и тестов; если нет — компилятор
нумерует сам детерминированно по порядку обхода), `priority: "primary" | "secondary"` (по умолчанию primary; secondary сворачивается первым).

| type | Поля | Привязка | Пределы (в `limits.ts`) |
| :--- | :--- | :--- | :--- |
| `Card` | `children: Node[]` | — | ровно один, только корень; глубина дерева ≤ 4 |
| `Header` | `title`, `subtitle?`, `badge?: StatusBadge` | через badge | title ≤ 80, subtitle ≤ 120 |
| `Text` | `text`, `tone?: "primary"\|"secondary"`, `selectable?: boolean` | `bind?` (текст из state) | ≤ 600 знаков, дальше — свёртка |
| `StatusBadge` | `bind`, `options: { [value]: { label, tone } }`, `value?` | **да** | ≤ 12 значений; label ≤ 24; tone: `neutral\|accent\|success\|warning\|danger` |
| `KeyValue` | `rows: { label, value, bind? }[]` | у value | ≤ 8 строк; label ≤ 32, value ≤ 80 |
| `TaskItem` | `num`, `title`, `due?`, `meta?`, `badge?`, `action?` (имя действия) | badge | title ≤ 80, due/meta ≤ 32 |
| `List` | `items: (TaskItem\|KeyValue)[]`, `pageSize?` (по умолчанию 5), `pager: { prev, next, of }` | — | ≤ 20 элементов, pageSize 3..5 |
| `Table` | `columns: string[]`, `rows: string[][]`, `align?: ("start"\|"end")[]` | — | ≤ 4 колонки, ≤ 8 строк, ячейка ≤ 25 |
| `ProgressBar` | `label?`, `bind`, `value?` (0..100) | **да** | — |
| `BarChart` | `bars: { label, value }[]`, `max?`, `caption?` | — | ≤ 12 столбцов, label ≤ 6 знаков |
| `Tabs` | `tabs: { title, children: Node[] }[]` | — | ≤ 3 вкладки, title ≤ 16; вкладки не вкладываются |
| `Accordion` | `sections: { title, children: Node[] }[]` | — | ≤ 6 разделов, title ≤ 60 |
| `ButtonRow` | `buttons: Button[]` | видимость через `act` | 1–3 кнопки, ровно одна `primary` в ряду с request |
| `Divider` | — | — | — |

`Button`:

```jsonc
{ "kind": "request", "label": "Взять",  "action": "claim",  "style": "primary" }   // TelegramWidget.request(actions[action])
{ "kind": "link",    "label": "Открыть в SAYF", "link": "open" }                    // openLink(links[link]) / openTelegramLink для t.me
{ "kind": "local",   "label": "Ещё",    "toggles": "more_section", "labelBack": "Назад" } // показать/скрыть узел с id
```

Пределы контракта §5, которые проверяются на уровне всего виджета: **≤ 3 кнопки-request видимых одновременно на одном экране**
(экран = текущая вкладка/страница/раскрытое «Ещё»); кнопка `local` скрывает/показывает узел с этим `id` в пределах той же `Card`.

### 4.3. Привязки (`bind`)

`bind` — имя ключа `state`. Компилятор ставит на элемент `data-b="<ключ>"` и рисует начальное значение из `state`. Связыватель
(§5.3) при `chatDataChanged` применяет новое значение:

| Компонент | Что меняется | Как |
| :--- | :--- | :--- |
| `Text`, `KeyValue.value` | текст | `textContent = String(v)` |
| `StatusBadge` | подпись и тон | подпись из встроенной таблицы `options` → `textContent`; тон → атрибут `data-t` |
| `ProgressBar` | ширина и число | `style.width = clamp(v,0,100)+"%"` (единственное разрешённое style-свойство), `textContent` |

Значение, которого нет в `options` у `StatusBadge`, игнорируется (остаётся прежнее). Нечисловое у `ProgressBar` — игнорируется.

### 4.4. Видимость кнопок (`act`)

HTML после отправки не меняется, поэтому в нём **заранее есть все кнопки всех действий с не-null строкой** (контракт §6.1).
`state.act` — массив имён действий, видимых сейчас. Нет `act` → видимы все. Связыватель ставит/снимает атрибут `hidden`
у кнопок `data-a="<имя>"`. Ряд, где все кнопки скрыты, скрывается целиком. Лишний на экране ряд не занимает высоту.

### 4.5. Ревизия

`state.r` — целое. Связыватель хранит последнюю применённую ревизию; пришедший `chatData` с `r` меньше текущей — игнорирует целиком.
Равный — применяет (идемпотентно). Битый JSON — игнорирует.

### 4.6. Служебные слова

```ts
interface ServiceWords {     // всё — необязательно; по умолчанию — знаки
  pending: string;           // "…"     пока ждём ответ бота
  failed: string;            // "⚠"     request отклонён: TIMEOUT/FAILED/INVALID_ANSWER
  busy: string;              // "⏳"    BUSY / RATE_LIMITED
  notAllowed: string;        // "⚠"     NOT_ALLOWED (превью, пересылка)
  ellipsis: string;          // "…"     при усечении
}
```

Слова может передать хост (в `CompileOptions.words`, или поле `words` в описании — оно главнее). Пакет языков не знает.

---

## 5. Что генерируется в HTML

### 5.1. Каркас

```html
<style>…только используемые фрагменты, фиксированный порядок…</style>
<div class="c" dir="…" lang="…">…узлы…</div>
<script>…только используемые куски рантайма…</script>
```

* Без `<!doctype>`, `<html>`, `<head>` — фрагмент разрешён гайдом и экономит байты.
* `body{margin:0;padding:12px 14px calc(12px + env(safe-area-inset-bottom))}` — отступ под время в углу (гайд, раздел THE BUBBLE).
  Альтернатива — ничего не ставить на body (UA-слой сам добавит отступ к «голому» body). Выбрать замером в фазе 1, записать в DECISIONS.
* Цвета — только `var(--tg-theme-*)`; приглушение — цветом `--tg-theme-hint-color`, **не opacity**. Никаких blur-теней и `filter`.
* Короткие классы (`.c`, `.h`, `.b`, `.kv` …) — карта классов в одном месте (`render/css.ts`), без пересечений.
* Каждый CSS-фрагмент имеет ключ; компонент при рендере регистрирует ключи; в `<style>` попадают только зарегистрированные, в порядке
  объявления в `css.ts` (детерминизм §4.4 контракта).
* Нет пробелов и переносов, кроме значимых. Нет комментариев.

### 5.2. Экранирование (обязательно, `src/escape.ts`)

| Куда | Правило |
| :--- | :--- |
| текст узла | `& < >` → сущности |
| значение атрибута | всегда в двойных кавычках; `& < > "` → сущности |
| JSON внутри `<script>` | `JSON.stringify`, затем `<` → `<`, `>` → `>`, `&` → `&`, U+2028/2029 → ` `/` ` |
| URL | только после проверки `links.ts`; затем как атрибут |

Перед экранированием `sanitize.ts`: удалить U+0000, управляющие C0 (кроме `\n`, `\t`) и C1, одиночные суррогаты. Bidi-символы
(U+202A–202E, U+2066–2069) **не удалять** (законный RTL-текст), но тест атак проверяет, что они не ломают разметку.

### 5.3. Рантайм виджета (`render/runtime.ts`)

Один `<script>`, собирается из кусочков; кусок попадает, только если нужен. Пишется вручную минимальным ES2023, без библиотек.

| Кусок | Нужен, если | Что делает |
| :--- | :--- | :--- |
| `base` | есть любой другой кусок | `const T=window.TelegramWidget,$=…`; функции поиска по `data-*` |
| `bind` | есть `bind` или `act` | разбор `chatData` в try/catch, проверка `r`, применение §4.3–4.4; подписка `onEvent('chatDataChanged')`; первый проход синхронно при загрузке |
| `req` | есть кнопка `request` | клик → синхронно `T.request(key)` (гайд: только синхронно в обработчике); кнопка `disabled` + слово `pending`; ответ: `result`-строку показать в строке статуса `textContent`; ошибка — слово по `e.code`; без `T` (сайт-предпросмотр) — ничего |
| `link` | есть кнопка `link` | клик → `T.openLink(url)` или `T.openTelegramLink(url)` для `https://t.me/` |
| `page` | есть `List` с > pageSize | показ страницы атрибутом `hidden`, кнопки «‹ › 1/2» |
| `tabs` | есть `Tabs` | переключение вкладок атрибутом `hidden`, активная — `aria-selected` + класс |
| `more` | есть кнопка `local` | `hidden` у целевого узла, смена подписи кнопки |
| `acc` | есть `Accordion` | на `toggle` закрыть остальные `<details>` той же группы (только один открыт — иначе прогноз высоты неверен) |

Действия и строки ссылок в HTML кладутся атрибутами `data-k` у кнопок (экранированно) — не в JS-литералах. Таблица `options`
`StatusBadge` — JSON в `<script>` по правилу §5.2. `innerHTML` в рантайме **не используется нигде** (тест-сторож ищет строку).

**Почему JS, а не CSS:** `:checked`, `:target`, `:has()` вне профиля (`profile-v1.md`, `sel.form-state`), поэтому вкладки и страницы
без скрипта не сделать.

**Без `TelegramWidget`** (предпросмотр на сайте SAYF): виджет рисуется из начального состояния, кнопки неактивны. Всё работает без исключений.

---

## 6. Конвейер компиляции (`compile.ts`)

```
unknown ─► validate (схема + пределы + ссылки + действия) ─► sanitize строк
        ─► plan: дерево + список возможных свёрток
        ─► loop: render → measure (utf8, deflate9, height) → в бюджете? ─да─► result
                                                              └нет─► следующий шаг свёртки ─► (шаги кончились) ─► too_large
        ─► chatDataOf(state) ─► caption
```

### 6.1. Проверка (`validate.ts`)

Рукописная, без библиотек. Собирает **все** нарушения с JSON-путями (`root.children[2].rows[9]`), не останавливаясь на первом.
Пределы — только из `limits.ts`. Отдельно: каждая `action` у кнопки/TaskItem есть в `actions`; каждая `link` есть в `links`;
`toggles` указывает на существующий `id`; `bind` — на существующий ключ `state`; id уникальны.

### 6.2. Измерение (`budget.ts`)

`utf8Bytes` — `new TextEncoder().encode(html).length`. `deflatedBytes` — порт `opts.deflate9`. Сравнение с 3 800 (не 4 096: Node
и сервер Telegram расходятся на десятки байт; точная проверка Python — в `scripts/check-widget.sh`).

### 6.3. Свёртка (`degrade.ts`) — порядок фиксирован контрактом §4.7

| Шаг | Что | Запись в `degraded` |
| :--- | :--- | :--- |
| 1 | `Text` с `priority: secondary` (затем самые длинные primary, кроме первого Text) — обернуть в `<details>` с первыми ~60 знаками в `<summary>` | `collapse:<id>` |
| 2 | `List` без страниц или с pageSize 5 → pageSize 4 → 3 | `paginate:<id>:<size>` |
| 3 | самые длинные тексты — усечь до предела + `ellipsis`; полный текст — в caption | `truncate:<id>:<chars>` |
| 4 | не помогло | ошибка `too_large` |

Шаги применяются по одному, после каждого — новое измерение. Внутри шага порядок кандидатов детерминирован: по убыванию длины,
при равенстве — по порядку обхода. **Кнопки, `ButtonRow`, `Header.title` и действия не трогаются никогда.**

### 6.4. Caption (`caption.ts`)

Если в описании есть — взять (обрезать по знакам до 1 024 с `ellipsis`). Если нет — собрать: `Header.title` · подпись статуса · первые
`KeyValue`. Если шаг 3 свёртки усёк текст — дописать полный текст (сколько влезет). Caption никогда не пуст: старый клиент видит только его.

### 6.5. `chatDataOf`

`JSON.stringify` состояния с ключами в порядке: `r` первым, затем по алфавиту (детерминизм). Проверка ≤ 1 024 байт UTF-8, иначе
`chat_data_too_large`. Используется и для начального `chat_data`, и шлюзом при каждом `editMessageWidgetData`.

---

## 7. Прогноз высоты на 320 px (`layout/height.ts`) — главный технический риск

Контракт требует `predictedHeight320` чистой функцией (без браузера). Реальную высоту знает только песочница (Chromium).

### 7.1. Модель

* Ширина содержимого: 320 − 2×14 (padding body) = 292 px.
* Для каждого компонента — функция «высота от содержимого»: фиксированные отступы + строки × высота строки.
* Строки текста: `ceil(ширина_текста / доступная_ширина)` по словам; ширина текста — сумма ширин знаков по классам:
  кириллица/латиница строчные, прописные, цифры, пробел, широкие (CJK, эмодзи = 1.2 em). Коэффициенты — в таблице, подбираются калибровкой.
* `List` — по самой высокой странице. `Tabs` — по самой высокой вкладке + полоса вкладок. `Accordion` — все `<summary>` + самый
  высокий **один** раздел (рантайм держит открытым только один, §5.3). «Ещё» — максимум из двух состояний.
* Скрытые `act`-ом кнопки считаются видимыми (худший случай).

### 7.2. Принцип

Прогноз должен быть **консервативным**: прогноз ≥ реальной высоты всегда, и не более чем на 20 % выше (иначе свёртка будет срабатывать зря).

### 7.3. Калибровка (`scripts/calibrate-height.ts`, dev)

Компилирует все образцы + 30–50 синтетических описаний (разные длины кириллицы, латиницы, узбекского, эмодзи), прогоняет каждое через
`sandbox-node.ts --width 320` (и все состояния: каждая страница, вкладка, раздел — через `--tap`), печатает таблицу «прогноз / факт /
ошибка» и предлагает коэффициенты. Тест `tests/height.test.ts` фиксирует инвариант §7.2 на образцах по сохранённым замерам
(`fixtures/*.expected.json` хранит `measuredHeight320`), чтобы тест работал без Chromium.

---

## 8. Тесты и проверки

### 8.1. Один набор тестов для vitest и Deno

Тесты пишутся с `import { describe, it, expect } from "vitest"`. В `deno.json` import map перенаправляет `"vitest"` на
`tests/_deno_vitest.ts`, который реэкспортирует `describe`/`it` из `jsr:@std/testing/bdd` и `expect` из `jsr:@std/expect`
(Jest-совместимый). Используются только общие матчеры: `toBe`, `toEqual`, `toMatchObject`, `toContain`, `toBeLessThanOrEqual`,
`toThrow`. jsr.io из окружения доступен (проверено 19.11). Если подход не взлетит — зеркальные файлы, решение в DECISIONS.

`deno.json` задачи: `check` (`deno check src/index.ts tests/` + `deno lint` + `deno test -A`), `schema` (build-schema).
`package.json`: `test` (vitest run), `typecheck` (tsc --noEmit).

### 8.2. Наборы

| Файл | Что проверяет |
| :--- | :--- |
| `escape.test.ts` | таблица §5.2 на граничных строках |
| `validate.test.ts` | каждый предел каталога: на пределе — принят, на пределе+1 — отвергнут с правильным путём |
| `compile.test.ts` | каждый компонент по отдельности; детерминизм (дважды → байт в байт); только используемые CSS/рантайм-куски |
| `golden.test.ts` | каждый `fixtures/*.spec.json` → совпадает с `.expected.html` и `.expected.json` байт в байт |
| `attacks.test.ts` | строки: `<script>`, `</script>`, `"><img src=x onerror=1>`, `javascript:alert(1)`, `data:text/html,…`, U+0000, U+2028, 5 000 знаков без пробела, RTL-override, `{{`, `${}`; в HTML нет ни тега, ни атрибута-обработчика вне шаблона; ссылки чужих доменов → `link_not_allowed` |
| `degrade.test.ts` | порядок шагов; кнопки никогда не выпадают; `degraded` совпадает с ожидаемым |
| `state.test.ts` | `chatDataOf`: порядок ключей, 1 024 байта ровно и +1, кириллица (512 букв), эмодзи |
| `height.test.ts` | инвариант §7.2 по сохранённым замерам |
| `schema.test.ts` | `schema/widget-spec.v1.json` == `widgetSpecSchema`; ajv принимает все образцы, отвергает испорченные (по одному на правило) |
| `prompt.test.ts` | `promptGuide()` упоминает все 14 компонентов и все пределы из `limits.ts` |
| `botapi.test.ts` | `answerPayload` режет по UTF-8, не разрывая символ (эмодзи, кириллица на границе 1 024); имена полей совпадают с `docs/telegram/bot-api-10.4-widgets.md` |
| `props.test.ts` | fast-check: случайные деревья каталога → валидный результат в бюджете или типизированная ошибка, никогда исключение |
| `guard.test.ts` | `src/` (кроме `measure-node.ts`) не содержит: `import` вне `./`/`../`, `Deno.`, `process`, `fetch(`, `Date`, `Math.random`, `innerHTML`, `node:`; все импорты с `.ts` |

### 8.3. Проверка песочницей (dev, вне `deno test`)

`scripts/check-widget.sh fixtures/*.expected.html` — Python zlib-9 ≤ 3 800, U+0000, валидатор Profile 1 без единой строки `diag`,
высота ≤ 560 px на 320 px, 0 «тяжёлых» элементов. Дополнительно прогнать с `--dark` (тёмная тема) и с `--tap` по кнопкам страниц,
вкладок, «Ещё» — высота каждого состояния ≤ 560. Для запросов: `--message private --answer '{"result":"готово"}'` и
`--set-data '{"chatData":"{\"r\":2,…}"}'` — проверить, что связыватель обновил статус и видимость кнопок.

### 8.4. Python

`scripts/check-schema.py`: `jsonschema` проверяет все образцы по `schema/widget-spec.v1.json` (так их увидит ядро SAYF на Pydantic).

---

## 9. Фазы

Оценка: **3–4 долгие сессии** coding-агента. Сложность ≈ 6/10: логика простая, трудности — прогноз высоты, бюджет на кириллице,
детерминированная свёртка и новизна технологии.

### Фаза 0. Каркас (≈ 0.2 сессии)

* `deno.json`, `package.json` (только devDependencies), `tsconfig.json`, `vitest.config.ts`, `tests/_deno_vitest.ts`.
* `src/index.ts` с заглушками, `src/measure-node.ts`, `guard.test.ts`.
* `docs/DECISIONS.md` с первыми решениями.

**Готово, когда:** `deno task check` и `npm test` зелёные на пустом пакете; тест-сторож работает (проверить, что ловит нарушение).

### Фаза 1. Ядро: типы, проверка, экранирование, 6 компонентов (≈ 0.8 сессии)

* `types.ts`, `limits.ts`, `errors.ts`, `validate.ts`, `sanitize.ts`, `escape.ts`, `budget.ts`.
* Компоненты: `Card`, `Header`, `Text`, `StatusBadge`, `KeyValue`, `ButtonRow` (только `request` и `link`), `Divider`.
* `render/css.ts` с ключами, рантайм-куски `base`, `bind`, `req`, `link`.
* `state.ts`, `caption.ts` (простая версия), `compile.ts` без свёртки (не влезло → `too_large`).
* Первые образцы: `task-short`, `decision-normal`, `decision-no-actions`.

**Готово, когда:** образцы проходят `check-widget.sh`; связыватель проверен в песочнице через `--set-data` (статус и кнопки меняются,
старая ревизия игнорируется); `escape`/`validate`/`attacks` (для этих компонентов)/`state` зелёные.

### Фаза 2. Остальной каталог и локальная интерактивность (≈ 0.8 сессии)

* `TaskItem`, `List` (+ `page`), `Table`, `ProgressBar`, `BarChart` (CSS-столбцы на flex, без SVG, если короче — проверить замером),
  `Tabs` (+ `tabs`), `Accordion` (+ `acc`), кнопка `local` (+ `more`).
* Образцы: `day-3`, `day-8` (8 задач кириллицей, 2 страницы), `task-long` (с «Ещё»), `report-week`, `report-12bars`, `reply-short`.

**Готово, когда:** все 5 сценариев контракта §6 компилируются; каждое состояние (страница/вкладка/раздел) ≤ 560 px в песочнице;
`day-8` ≤ 3 800 байт zlib-9 (исследование даёт ≈ 1 754 для сравнения).

### Фаза 3. Прогноз высоты и свёртка (≈ 0.7 сессии)

* `layout/height.ts`, `scripts/calibrate-height.ts`, сохранённые замеры в `expected.json`.
* `degrade.ts` с тремя шагами, полный `caption.ts` (перенос усечённого текста).
* Образцы: `reply-1500` (≈ 1 500 знаков кириллицы с разделами), `reply-too-long` (ожидаемая `too_large` или свёртка с записью),
  `task-uz` (узбекский с `o‘`, `g‘`), `reply-emoji`, `table-rtl` (одна ячейка на иврите/арабском для проверки bidi).

**Готово, когда:** инвариант §7.2 держится на всех образцах; `degrade.test.ts` зелёный; ни одна кнопка не выпала ни в одном образце.

### Фаза 4. Схема, подсказка модели, свойства (≈ 0.6 сессии)

* `schema.ts` из `limits.ts` (draft 2020-12, рекурсия через `$defs`), `scripts/build-schema.ts` → `schema/widget-spec.v1.json`.
* `prompt.ts`: что такое виджет, каталог с пределами, 2 коротких образца, правила (тексты готовые, без разметки, ≤ 3 действия, длинное — не виджетом).
* `schema.test.ts`, `prompt.test.ts`, `props.test.ts` (fast-check), `scripts/check-schema.py`.

**Готово, когда:** схема принимает все образцы и отвергает испорченные; Python-проверка зелёная; fast-check 1 000 прогонов без исключений.

### Фаза 5. Типы и помощники Bot API (≈ 0.3 сессии)

* `botapi/types.ts` — **поле в поле** по `docs/telegram/bot-api-10.4-widgets.md`: `SendWidgetParams`, `EditMessageWidgetDataParams`,
  `AnswerWidgetQueryParams`, `WidgetQuery`, `Update.widget_query` (только нужное шлюзу; `sendSharedWidget`/`editSharedWidgetData` —
  типами, но с пометкой «не для данных компании», контракт §10).
* `toSendWidgetParams(result, chatId, opts)`, `toEditWidgetDataParams(chatId, messageId, chatData)`, `answerPayload(text)`.

**Готово, когда:** `botapi.test.ts` зелёный.

### Фаза 6. Золотой набор и сдача (≈ 0.4 сессии)

* Дособрать набор до 14–16 образцов (по 2–3 на сценарий: короткий, длинный, кириллица, узбекский, эмодзи; тёмная тема — тот же HTML,
  проверенный `--dark`).
* `scripts/build-fixtures.ts --update` и ревью диффа глазами.
* `docs/API.md` — публичный API с примерами для шлюза (Deno) и ядра (Python: как брать схему и подсказку).
* Прогон всего раздела §9 контракта, отчёт о результатах в `docs/REPORT.md` (что проверено, цифры размеров и высот по каждому образцу).

**Готово, когда:** все пункты §9 контракта выполнены (кроме живого бота) и подтверждены командами в отчёте.

### Фаза 7 (по желанию). Пример бота на telegym

`examples/telegym-bot/`: Deno-скрипт отправляет образцы через `sendWidget` в мок telegym, принимает `widget_query`, отвечает
`answerWidgetQuery`, правит `editMessageWidgetData`. Ключ — только из окружения. Не в `src/`.

---

## 10. Образцы золотого набора

| Имя | Сценарий §6 | Проверяет |
| :--- | :--- | :--- |
| `task-short` | 6.1 | 3 кнопки, статус `bind`, `act` |
| `task-long` | 6.1 | «Ещё» с описанием и второй тройкой кнопок |
| `task-uz` | 6.1 | узбекская латиница с `‘` |
| `day-3` | 6.2 | короткий список, без страниц |
| `day-8` | 6.2 | 8 задач кириллицей, страницы по 5, номер → `request("t:…:open")` |
| `decision-normal` | 6.3 | KeyValue ×8, 3 кнопки, «Подробнее» Accordion |
| `decision-no-actions` | 6.3 | высокий риск: без `actions`, «решается в SAYF» + ссылка |
| `decision-uz` | 6.3 | узбекский |
| `reply-short` | 6.4 | подпись помощника, источники, «Голосом» |
| `reply-1500` | 6.4 | 1 500 знаков кириллицы в разделах |
| `reply-emoji` | 6.4 | эмодзи (ширина в прогнозе высоты) |
| `reply-too-long` | 6.4 | ожидаемая свёртка или `too_large` (запасное лицо — текст) |
| `report-week` | 6.5 | KeyValue ×4, BarChart ×7, ProgressBar |
| `report-12bars` | 6.5 | BarChart ×12 |
| `table-rtl` | — | Table 4×8, RTL-ячейка, ячейки по 25 знаков |
| `attack-strings` | — | все строки атак в видимых полях; HTML совпадает с ожидаемым |

Данные — обезличенные; ключи действий — образцы формы (`t:Ab3kQ9xYz1LmN0pQrStUv_:claim`, 22 знака).

---

## 11. Риски и что делать

| Риск | Признак | Действие |
| :--- | :--- | :--- |
| Прогноз высоты неточен | калибровка даёт ошибку > 20 % | грубее и консервативнее коэффициенты; меньше pageSize по умолчанию; записать в DECISIONS |
| Не влезает в 3 800 на длинной кириллице | `reply-1500` > 3 800 | сократить CSS/рантайм, классы короче; если нет — 1 500 знаков становятся пределом с `too_large`, контракт это допускает (§6.4: «длиннее бюджета — текстом») |
| Рантайм большой | > 900 байт zlib-9 со всеми кусками | проверить, что куски не тянутся без нужды; ужать вручную |
| Deno и vitest расходятся | тест зелёный в одном и красный в другом | использовать только общие матчеры (§8.1); иначе зеркальные файлы |
| Схема не годится для structured output модели | ядро SAYF сообщит об отказе | держать схему простой (без `oneOf` с перекрытием, дискриминатор `type` в каждом узле); упрощённый вариант — отдельным файлом по запросу SAYF |
| Сервер Telegram отключит виджеты (`INPUT_MEDIA_WIDGET_NOT_ALLOWED`) | — | не наша зона: шлюз шлёт текстом (контракт §3). Пакет не меняется |
| Профиль Telegram изменится | новая версия widget-sandbox | `VERSION.json` в vendor: profile 1; при смене — перепроверить образцы `check-widget.sh` |

---

## 12. Решения, принятые этим планом сверх контракта (перенести в `docs/DECISIONS.md`)

1. Компонентов 14 (контракт перечисляет 13 «исследования» + `List`): `List` — отдельный контейнер страниц.
2. Видимость кнопок — зарезервированный ключ `state.act`; кнопки с `null`-действием в HTML не попадают.
3. Таблица подписей `StatusBadge` живёт в HTML (экономит `chat_data`), а `chat_data` несёт только значение.
4. Вкладки, страницы, «Ещё», «один открытый раздел» — на JS с атрибутом `hidden` (CSS-способы вне профиля).
5. HTML — фрагмент без `<!doctype>`/`<html>`.
6. `compileWidget` возвращает `Result`, не бросает.
7. Порядок ключей `chat_data`: `r` первым, остальные по алфавиту.
8. Один набор тестов на `vitest`-API; Deno — через import map на `@std/testing/bdd` + `@std/expect`.
9. Прогноз высоты консервативный (≥ факта, ≤ +20 %), калибруется по песочнице, замеры хранятся в образцах.
10. Служебные слова по умолчанию — знаки (`…`, `⚠`, `⏳`), не слова.

**Вопросы владельцу, на которые план дал ответ по умолчанию** (можно поменять до начала фазы 1):

* Отступ под время: свой `padding` с `env(safe-area-inset-bottom)` или UA-умолчание? — по умолчанию: решить замером.
* Показывать ли текст ответа бота (`result`) в строке статуса виджета? — по умолчанию: да, `textContent`, ≤ 1 строки.
* `BarChart` — CSS или SVG? — по умолчанию: то, что меньше по zlib-9 на `report-12bars`.

---

## 13. Чего не делать (сводка контракта §10 + плана)

* Не тянуть в `src/` и в HTML виджета ничего чужого: Zod, React, Preact, Chart.js, json-render, grammY.
* Не давать модели писать HTML; не вызывать модель из пакета.
* Не класть списки и длинные тексты в `chat_data`; не использовать `is_shared`/`public_data` для данных компании.
* Не использовать `innerHTML` в рантайме, `opacity < 1`, blur, `filter`, `vh`, внешние ресурсы, `<input>`.
* Не обрезать молча: каждая свёртка — в `degraded`, иначе `too_large`.
* Не строить бота, базу, права, очереди; живой бот — только `examples/`, ключ из окружения.
* Не править вручную `schema/widget-spec.v1.json`, `docs/telegram/*.md`, `fixtures/*.expected.*` — только генераторами.
