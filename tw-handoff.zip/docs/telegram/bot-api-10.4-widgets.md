# Bot API 10.4 — widget methods and types

Generated from the scrape of https://core.telegram.org/bots/api in telegym (`pkg/mock/spec/api.json`). Field texts are Telegram's own wording. Regenerate, do not edit by hand. For behaviour inside the widget (QuickJS, profile, SDK) see `vendor/widget-sandbox/docs/`.

## Changelog entry

https://core.telegram.org/bots/api#november-9-2026

## Methods

### sendWidget

Use this method to send a message with an HTML widget. Currently, in the production environment, widgets can be sent only to private chats, and sent widgets automatically have protected content and therefore can't be forwarded. On success, the sent Message is returned.

Returns: Message

| Field | Type | Required | Description |
|---|---|---|---|
| `chat_id` | Integer or String | yes | Unique identifier for the target chat or username of the target supergroup in the format @username |
| `message_thread_id` | Integer | optional | Unique identifier for the target message thread (topic) of a forum; for forum supergroups and private chats of bots with forum topic mode enabled only |
| `html` | String | yes | HTML code of the widget, 1-32768 bytes. The code must not exceed 4096 bytes when compressed by zlib with the maximum compression level. |
| `width` | Integer | optional | Width of the widget in logical pixels; omit if the widget must occupy the whole width of the message bubble. The width is clamped by the app to the range from 200 to the maximum width of the message bubble. |
| `height` | Integer | optional | Height of the widget in logical pixels; omit if the height of the widget isn't fixed. The height is clamped by the app to the range 50-600. |
| `public_data` | String | optional | Public data of the widget, 0-1024 bytes, which will be available wherever the widget is shown. If the widget is shared, then all messages with it will have the same public data. |
| `chat_data` | String | optional | Data of the widget, which is specific to the message, 0-1024 bytes |
| `caption` | String | optional | Widget caption, 0-1024 characters after entities parsing |
| `parse_mode` | String | optional | Mode for parsing entities in the widget caption. See formatting options for more details. |
| `caption_entities` | Array of MessageEntity | optional | A JSON-serialized list of special entities that appear in the caption, which can be specified instead of parse_mode |
| `show_caption_above_media` | Boolean | optional | Pass True if the caption must be shown above the widget |
| `allow_queries` | Boolean | optional | Pass True to allow the widget to send queries to the bot |
| `is_shared` | Boolean | optional | Pass True to create a shared widget, which can be sent again using the method sendSharedWidget |
| `disable_notification` | Boolean | optional | Sends the message silently. Users will receive a notification with no sound. |
| `protect_content` | Boolean | optional | Protects the contents of the sent message from forwarding and saving |
| `allow_paid_broadcast` | Boolean | optional | Pass True to allow up to 1000 messages per second, ignoring broadcasting limits for a fee of 0.1 Telegram Stars per message. The relevant Stars will be withdrawn from the bot's balance. |
| `message_effect_id` | String | optional | Unique identifier of the message effect to be added to the message; for private chats only |
| `reply_parameters` | ReplyParameters | optional | Description of the message to reply to |
| `reply_markup` | InlineKeyboardMarkup or ReplyKeyboardMarkup or ReplyKeyboardRemove or ForceReply | optional | Additional interface options. A JSON-serialized object for an inline keyboard, custom reply keyboard, instructions to remove a reply keyboard or to force a reply from the user. |

### sendSharedWidget

Use this method to send again a shared widget created by the bot. Currently, in the production environment, widgets can be sent only to private chats, and sent widgets automatically have protected content and therefore can't be forwarded. On success, the sent Message is returned.

Returns: Message

| Field | Type | Required | Description |
|---|---|---|---|
| `chat_id` | Integer or String | yes | Unique identifier for the target chat or username of the target supergroup in the format @username |
| `message_thread_id` | Integer | optional | Unique identifier for the target message thread (topic) of a forum; for forum supergroups and private chats of bots with forum topic mode enabled only |
| `widget_id` | String | yes | Unique identifier of the shared widget |
| `chat_data` | String | optional | Data of the widget, which is specific to the message, 0-1024 bytes |
| `caption` | String | optional | Widget caption, 0-1024 characters after entities parsing |
| `parse_mode` | String | optional | Mode for parsing entities in the widget caption. See formatting options for more details. |
| `caption_entities` | Array of MessageEntity | optional | A JSON-serialized list of special entities that appear in the caption, which can be specified instead of parse_mode |
| `show_caption_above_media` | Boolean | optional | Pass True if the caption must be shown above the widget |
| `disable_notification` | Boolean | optional | Sends the message silently. Users will receive a notification with no sound. |
| `protect_content` | Boolean | optional | Protects the contents of the sent message from forwarding and saving |
| `allow_paid_broadcast` | Boolean | optional | Pass True to allow up to 1000 messages per second, ignoring broadcasting limits for a fee of 0.1 Telegram Stars per message. The relevant Stars will be withdrawn from the bot's balance. |
| `message_effect_id` | String | optional | Unique identifier of the message effect to be added to the message; for private chats only |
| `reply_parameters` | ReplyParameters | optional | Description of the message to reply to |
| `reply_markup` | InlineKeyboardMarkup or ReplyKeyboardMarkup or ReplyKeyboardRemove or ForceReply | optional | Additional interface options. A JSON-serialized object for an inline keyboard, custom reply keyboard, instructions to remove a reply keyboard or to force a reply from the user. |

### answerWidgetQuery

Use this method to send an answer to a query from a widget. The query must be answered within 15 seconds. The answer is received only by the widget that sent the query and doesn't change data of the widget; use editMessageWidgetData or editSharedWidgetData to change it. On success, True is returned.

Returns: Boolean

| Field | Type | Required | Description |
|---|---|---|---|
| `widget_query_id` | String | yes | Unique identifier for the query to be answered |
| `data` | String | optional | Data to be returned to the widget, 0-1024 bytes |

### editMessageWidgetData

Use this method to edit data of a widget in a message sent by the bot or via the bot (for inline bots). Public data of a shared widget can be changed at most once per second. On success, True is returned.

Returns: Boolean

| Field | Type | Required | Description |
|---|---|---|---|
| `chat_id` | Integer or String | optional | Required if inline_message_id is not specified. Unique identifier for the target chat or username of the target supergroup in the format @username. |
| `message_id` | Integer | optional | Required if inline_message_id is not specified. Identifier of the message with the widget. |
| `inline_message_id` | String | optional | Required if chat_id and message_id are not specified. Identifier of the inline message. |
| `public_data` | String | optional | New public data of the widget, 0-1024 bytes; pass an empty string to remove the public data. If omitted, then the public data isn't changed. |
| `chat_data` | String | optional | New data of the widget, which is specific to the message, 0-1024 bytes; pass an empty string to remove the data. If omitted, then the data isn't changed. |

### editSharedWidgetData

Use this method to edit public data of a shared widget created by the bot. A shared widget can be edited at most once per second. On success, True is returned.

Returns: Boolean

| Field | Type | Required | Description |
|---|---|---|---|
| `widget_id` | String | yes | Unique identifier of the shared widget |
| `public_data` | String | yes | New public data of the widget, 0-1024 bytes; pass an empty string to remove the public data |
| `cache_time` | Integer | optional | The maximum amount of time in seconds that the public data of the widget may be cached client-side; 5-3600. If omitted, then the current value is kept, which is 30 by default. |

## Types (widget-specific, and existing types that gained widget fields)

### Update (widget-related fields only)

This object represents an incoming update.

At most one of the optional fields can be present in any given update.

| Field | Type | Required | Description |
|---|---|---|---|
| `widget_query` | WidgetQuery | optional | Optional. New incoming query from a widget in a message sent by the bot or via the bot |
| `shared_widget_query` | SharedWidgetQuery | optional | Optional. New incoming query from a forwarded message with a shared widget |

### Message (widget-related fields only)

This object represents a message.

| Field | Type | Required | Description |
|---|---|---|---|
| `widget` | Widget | optional | Optional. Message is an HTML widget, information about the widget |
| `caption` | String | optional | Optional. Caption for the animation, audio, document, live photo, paid media, photo, video, voice, or widget |
| `show_caption_above_media` | Boolean | optional | Optional. True, if the caption must be shown above the message media or the widget |
| `connected_website` | String | optional | Optional. The domain name of the website on which the user has logged in. More about Telegram Login: https://core.telegram.org/widgets/login |

### ExternalReplyInfo (widget-related fields only)

This object contains information about a message that is being replied to, which may come from another chat or forum topic.

| Field | Type | Required | Description |
|---|---|---|---|
| `widget` | Widget | optional | Optional. Message is an HTML widget, information about the widget |

### Widget

This object describes an HTML widget.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | String | optional | Optional. Unique identifier of the shared widget, which can be used to send the widget again using the method sendSharedWidget; omitted if the widget isn't shared |
| `width` | Integer | optional | Optional. Width of the widget in logical pixels; omitted if the widget must occupy the whole width of the message bubble |
| `height` | Integer | optional | Optional. Height of the widget in logical pixels; omitted if the height of the widget isn't fixed |
| `html` | String | yes | HTML code of the widget |
| `public_data` | String | optional | Optional. Public data of the widget, which is available wherever the widget is shown. All messages with a shared widget have the same public data. |
| `chat_data` | String | optional | Optional. Data of the widget, which is specific to the message |

### InlineKeyboardButton (widget-related fields only)

This object represents one button of an inline keyboard. Exactly one of the fields other than text, icon_custom_emoji_id, and style must be used to specify the type of the button.

| Field | Type | Required | Description |
|---|---|---|---|
| `login_url` | LoginUrl | optional | Optional. An HTTPS URL used to automatically authorize the user. Can be used as a replacement for the Telegram Login Widget. Not supported for ephemeral messages. |

### WidgetQueryType

This object describes the type of a query from a widget. Currently, it can be one of

- WidgetQueryTypeData

- WidgetQueryTypeSignData

- WidgetQueryTypeSentTransaction

_no fields_

Subtypes: WidgetQueryTypeData, WidgetQueryTypeSignData, WidgetQueryTypeSentTransaction

### WidgetQueryTypeData

The query contains data for the bot.

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | String | yes | Type of the query, always "data" |
| `wallet_card` | TonWalletCard | optional | Optional. TON wallet card of the user who sent the query, if it was sent to the bot along with the query |

### WidgetQueryTypeSignData

The query contains data signed by a TON wallet of the user who sent the query. The data is signed for the domain bot<bot_id>, where <bot_id> is the identifier of the bot.

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | String | yes | Type of the query, always "sign_data" |
| `wallet` | WidgetQueryWallet | yes | The wallet that signed the data |
| `sign_data` | String | yes | JSON-serialized signed data |

### WidgetQueryTypeSentTransaction

The query notifies the bot about a transaction sent from a TON wallet of the user who sent the query.

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | String | yes | Type of the query, always "sent_transaction" |
| `wallet` | WidgetQueryWallet | yes | The wallet from which the transaction was sent |
| `msg_hash` | String | yes | Value of msg_hash of the transaction |

### WidgetQueryWallet

This object describes a TON wallet of the user, which is used in a query from a widget.

| Field | Type | Required | Description |
|---|---|---|---|
| `address` | String | yes | Address of the wallet |
| `amount` | String | yes | Balance of the wallet, in the smallest units of the cryptocurrency, as a decimal number |
| `public_key` | String | optional | Optional. Hex-encoded public key of the wallet; omitted if unknown |
| `state_init` | String | optional | Optional. Base64-encoded serialized StateInit of the wallet contract; omitted if and only if public_key is omitted |

### WidgetQuery

This object represents an incoming query from a widget in a message sent by the bot or via the bot. Use answerWidgetQuery to answer the query. Each user can send at most 5 queries per 5 seconds to the bot from all its widgets.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | String | yes | Unique identifier for this query |
| `from` | User | yes | Sender |
| `chat` | Chat | optional | Optional. Chat with the message containing the widget; omitted if the widget is in an inline message |
| `message_id` | Integer | optional | Optional. Identifier of the message containing the widget; omitted if the widget is in an inline message |
| `inline_message_id` | String | optional | Optional. Identifier of the inline message containing the widget |
| `chat_instance` | String | yes | Global identifier, uniquely corresponding to the chat to which the message with the widget was sent |
| `chat_type` | String | optional | Optional. For widgets in inline messages, type of the chat to which the message was sent. Can be either "sender" for a private chat with the inline query sender, "private", "group", "supergroup", or "channel". |
| `type` | WidgetQueryType | yes | Type of the query |
| `data` | String | yes | Data of the query, 1-64 bytes |
| `widget_id` | String | optional | Optional. Unique identifier of the shared widget, which sent the query; omitted if the widget isn't shared |

### SharedWidgetQuery

This object represents an incoming query from a forwarded message with a shared widget created by the bot. Use answerWidgetQuery to answer the query. Each user can send at most 5 queries per 5 seconds to the bot from all its widgets.

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | String | yes | Unique identifier for this query |
| `from` | User | yes | Sender |
| `type` | WidgetQueryType | yes | Type of the query |
| `data` | String | yes | Data of the query, 1-64 bytes |
| `widget_id` | String | yes | Unique identifier of the shared widget, which sent the query |

### ChatMemberRestricted (widget-related fields only)

Represents a chat member that is under certain restrictions in the chat. Supergroups only.

| Field | Type | Required | Description |
|---|---|---|---|
| `can_send_other_messages` | Boolean | yes | True, if the user is allowed to send animations, games, stickers, widgets and use inline bots |

### ChatPermissions (widget-related fields only)

Describes actions that a non-administrator user is allowed to take in a chat.

| Field | Type | Required | Description |
|---|---|---|---|
| `can_send_other_messages` | Boolean | optional | Optional. True, if the user is allowed to send animations, games, stickers, widgets and use inline bots |

### RichMessageButton (widget-related fields only)

This object represents a button in a RichMessage. Exactly one of the fields other than text and style must be used to specify the type of the button.

| Field | Type | Required | Description |
|---|---|---|---|
| `login_url` | LoginUrl | optional | Optional. An HTTPS URL used to automatically authorize the user. Can be used as a replacement for the Telegram Login Widget. Not supported for ephemeral messages. |

### InputWidgetMessageContent

Represents the content of a message with an HTML widget to be sent as the result of an inline query. Currently, widgets can't be sent in response to inline queries in the production environment.

| Field | Type | Required | Description |
|---|---|---|---|
| `html` | String | yes | HTML code of the widget, 1-32768 bytes. The code must not exceed 4096 bytes when compressed by zlib with the maximum compression level. |
| `width` | Integer | optional | Optional. Width of the widget in logical pixels; omit if the widget must occupy the whole width of the message bubble. The width is clamped by the app to the range from 200 to the maximum width of the message bubble. |
| `height` | Integer | optional | Optional. Height of the widget in logical pixels; omit if the height of the widget isn't fixed. The height is clamped by the app to the range 50-600. |
| `public_data` | String | optional | Optional. Public data of the widget, 0-1024 bytes, which will be available wherever the widget is shown. If the widget is shared, then all messages with it will have the same public data. |
| `chat_data` | String | optional | Optional. Data of the widget, which is specific to the message, 0-1024 bytes |
| `caption` | String | optional | Optional. Widget caption, 0-1024 characters after entities parsing |
| `parse_mode` | String | optional | Optional. Mode for parsing entities in the widget caption. See formatting options for more details. |
| `caption_entities` | Array of MessageEntity | optional | Optional. List of special entities that appear in the caption, which can be specified instead of parse_mode |
| `show_caption_above_media` | Boolean | optional | Optional. Pass True if the caption must be shown above the widget |
| `allow_queries` | Boolean | optional | Optional. Pass True to allow the widget to send queries to the bot |
| `is_shared` | Boolean | optional | Optional. Pass True to create a shared widget. Each message sent from the result creates a separate shared widget, whose identifier is received by the bot only in the field widget_id of queries from the widget. To send an existing shared widget in response to an inline query, use InputSharedWidgetMessageContent instead. |

### InputSharedWidgetMessageContent

Represents the content of a message with a shared widget to be sent as the result of an inline query. Currently, widgets can't be sent in response to inline queries in the production environment.

| Field | Type | Required | Description |
|---|---|---|---|
| `widget_id` | String | yes | Unique identifier of the shared widget created by the bot |
| `chat_data` | String | optional | Optional. Data of the widget, which is specific to the message, 0-1024 bytes |
| `caption` | String | optional | Optional. Widget caption, 0-1024 characters after entities parsing |
| `parse_mode` | String | optional | Optional. Mode for parsing entities in the widget caption. See formatting options for more details. |
| `caption_entities` | Array of MessageEntity | optional | Optional. List of special entities that appear in the caption, which can be specified instead of parse_mode |
| `show_caption_above_media` | Boolean | optional | Optional. Pass True if the caption must be shown above the widget |
