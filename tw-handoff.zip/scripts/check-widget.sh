#!/usr/bin/env bash
# Check compiled widget HTML files: exact zlib-9 size (Python = Telegram's server), the official
# Widget Profile 1 sandbox, and the height at 320 px in headless Chromium.
# Usage: scripts/check-widget.sh file.html [more.html ...]   Exit 1 if any check fails.
set -uo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
sb="$root/vendor/widget-sandbox"
[ -d "$sb/node_modules" ] || { echo "run scripts/setup-vendor.sh first" >&2; exit 2; }
fail=0
for f in "$@"; do
  abs="$(cd "$(dirname "$f")" && pwd)/$(basename "$f")"
  echo "== $f"
  python3 -I -c '
import sys, zlib
b = open(sys.argv[1], "rb").read(); z = len(zlib.compress(b, 9))
bad = []
if len(b) > 32768: bad.append("utf8 > 32768")
if z > 3800: bad.append("zlib9 > 3800 (SAYF margin under 4096)")
if b"\x00" in b: bad.append("contains U+0000")
print(f"utf8 {len(b)} B, zlib9 {z} B (SAYF limit 3800, Telegram 4096)", "FAIL: " + "; ".join(bad) if bad else "ok")
sys.exit(1 if bad else 0)' "$abs" || fail=1
  out="$(cd "$sb" && corepack pnpm -s tsx packages/core/scripts/sandbox-node.ts "$abs" --verbose --width 320 2>&1)"
  rc=$?
  echo "$out" | grep -E '^(size|nodes|height|paint|main thread|batches)|diag|removed|out of profile|error|Error|stopped' | grep -v '^ops' | cut -c1-400
  [ $rc -eq 0 ] || { echo "FAIL: sandbox exit $rc"; fail=1; }
  h="$(echo "$out" | sed -n 's/^height \([0-9]*\) px.*/\1/p')"
  if [ -n "$h" ] && [ "$h" -gt 560 ]; then echo "FAIL: height $h px > 560 at 320 px"; fail=1; fi
  # the sandbox exits 0 even when it drops out-of-profile features: treat every diag as a failure
  if echo "$out" | grep -qE '^(diag|\[diag\])'; then echo "FAIL: sandbox diagnostics (out-of-profile or blocked)"; fail=1; fi
  hv="$(echo "$out" | sed -n 's/^paint: \([0-9]*\) heavy.*/\1/p')"
  if [ -n "$hv" ] && [ "$hv" -gt 0 ]; then echo "FAIL: $hv heavy boxes (spec TW §5: no blur/filter/opacity<1)"; fail=1; fi
done
exit $fail
