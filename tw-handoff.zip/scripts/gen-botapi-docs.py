"""Build docs/telegram/bot-api-10.4-widgets.md from telegym's scrape of core.telegram.org/bots/api.
Usage: python3 -I scripts/gen-botapi-docs.py vendor/telegym/pkg/mock/spec/api.json docs/telegram/bot-api-10.4-widgets.md"""
import json, sys
src, out = sys.argv[1], sys.argv[2]
d = json.load(open(src, encoding="utf-8"))
def is_widget(name, obj):
    if "idget" in name: return True
    return any("idget" in f["name"] or "idget" in f.get("description", "") for f in obj.get("fields", []))
def table(fields, method):
    if not fields: return "_no fields_\n"
    rows = ["| Field | Type | Required | Description |", "|---|---|---|---|"]
    for f in fields:
        desc = f.get("description", "").replace("|", "\\|").replace("\n", " ")
        rows.append(f"| `{f['name']}` | {' or '.join(f['types'])} | {'yes' if f.get('required') else 'optional'} | {desc} |")
    return "\n".join(rows) + "\n"
L = [f"# {d['version']} — widget methods and types\n",
     f"Generated from the scrape of https://core.telegram.org/bots/api in telegym (`pkg/mock/spec/api.json`). "
     "Field texts are Telegram's own wording. Regenerate, do not edit by hand. For behaviour inside the widget "
     "(QuickJS, profile, SDK) see `vendor/widget-sandbox/docs/`.\n"]
cl = d.get("changelog")
if cl:
    L.append("## Changelog entry\n")
    L.append((cl if isinstance(cl, str) else "\n".join(f"- {x}" for x in cl) if isinstance(cl, list) else json.dumps(cl, ensure_ascii=False, indent=1)) + "\n")
L.append("## Methods\n")
for n, m in d["methods"].items():
    if is_widget(n, m):
        L += [f"### {n}\n", "\n\n".join(m.get("description", [])) + "\n", f"Returns: {', '.join(m.get('returns', []))}\n", table(m.get("fields", []), True)]
L.append("## Types (widget-specific, and existing types that gained widget fields)\n")
for n, t in d["types"].items():
    if is_widget(n, t):
        fields = t.get("fields", [])
        if "idget" not in n:
            fields = [f for f in fields if "idget" in f["name"] or "idget" in f.get("description", "")]
            L.append(f"### {n} (widget-related fields only)\n")
        else:
            L.append(f"### {n}\n")
        L += ["\n\n".join(t.get("description", [])) + "\n", table(fields, False)]
        if t.get("subtypes"): L.append("Subtypes: " + ", ".join(t["subtypes"]) + "\n")
open(out, "w", encoding="utf-8").write("\n".join(L))
print(out, sum(1 for _ in open(out, encoding="utf-8")), "lines")
