#!/usr/bin/env bash
# Clone reference repos into vendor/ at pinned commits and install the sandbox. Idempotent.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p vendor
pin() { # name url commit
  if [ ! -d "vendor/$1/.git" ]; then git clone -q "$2" "vendor/$1"; fi
  git -C "vendor/$1" fetch -q --depth 1 origin "$3" 2>/dev/null || true
  git -C "vendor/$1" -c advice.detachedHead=false checkout -q "$3"
}
pin widget-sandbox https://github.com/TelegramMessenger/widget-sandbox 1cde0068daba8437f53eac0b61c395d29b8f89e3
pin json-render    https://github.com/vercel-labs/json-render       9301e64eb556f972c21eb471ae851603cab65e6b
pin telegym        https://github.com/kolomiichenko/telegym         d572188f9d45764e4b26bb3568400c8908dc2a0e
(cd vendor/widget-sandbox && PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 COREPACK_ENABLE_DOWNLOAD_PROMPT=0 corepack pnpm install --frozen-lockfile)
command -v deno >/dev/null || npm i -g deno
echo "vendor ready"
